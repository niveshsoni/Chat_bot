import os
from dotenv import load_dotenv
from hybrid_rrf_search import HybridRRFSearch
from langchain_core.prompts import PromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.runnables import RunnableSequence

# === Load API key ===
#load_dotenv()
GOOGLE_API_KEY = "AIzaSyBQIKEIBPWZ_f7SQxJsLXkTnrW5fNcJAVA"

# === LangChain Gemini Model ===
llm = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash",
    temperature=0.2,
    google_api_key=GOOGLE_API_KEY
)

# === LangChain Prompt ===
from langchain_core.prompts import PromptTemplate

prompt_template = PromptTemplate.from_template("""
You are a strict assistant. Use only the context below to answer the question.

### INSTRUCTIONS:
- Return only content from the context, grouped by the title it appears under.
- For each page where content is relevant, show:
  Title: <title>
  Answer: <exact matching content from that page>
- If the answer spans multiple titles, repeat the same format for each.
- Do NOT rephrase, summarize, or guess.
- If the answer is not found in the context, return exactly:
  ERROR 504: Content not found.

---

Context:
{context}

---

Question:
{question}

### Output:
""")


# === Hybrid Search Setup ===
DB_CONFIG = {
    'dbname': 'vector_db',
    'user': 'vector_user',
    'password': 'vector_pass',
    'host': 'localhost',
    'port': 5432
}
TABLE_NAME = 'updated_finance_20June2025_table'

searcher = HybridRRFSearch(
    db_config=DB_CONFIG,
    table_name=TABLE_NAME,
    sql_output_file="hybrid_query_debug.txt"
)

# === Get user question ===
question = input("❓ Ask your question: ").strip()

# === Retrieve top chunks ===
results = searcher.ask_question(question)
context_docs = "\n\n".join([r["document"] for r in results])
print(context_docs)

# === Chain: Prompt → Gemini → Output ===
chain = prompt_template | llm

# === Invoke
response = chain.invoke({
    "context": context_docs,
    "question": question
})

# === Show Result
print("\n🧠 Gemini Answer:\n")
print(response.content)
